/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestordocuments;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.List;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author 1195733
 */
public class main_paraula {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here

        int num;
        System.out.println("Classe Paraula");               
        
        //System.out.println("Introdueix una nova paraula per a la constructora buida");
        Scanner lector = new Scanner(System.in); 
        
        System.out.println("Escriu un numero del 1 al 4.");
        System.out.println("1. Crear una nova constructora amb un string");
        System.out.println("2. Funció set i Imprimir la paraula");
        System.out.println("3. Comprovem si es una stop word");
        System.out.println("4. Introduim paraula i fem servir funcio get");

           
        String opt = lector.next();

        num = Integer.parseInt(opt);
        
       switch(num)
       {
           case 1: System.out.println("Introdueix una nova paraula per la constructora");
                    String str = lector.next();
                    Paraula w = new Paraula(str);
                    w.imprimir(); break;
               
               
           case 2: Paraula p = new Paraula();
                    String option = lector.next();
                    p.set_p(option);
                    p.imprimir();break;
               
               
           case 3:  Paraula pa = new Paraula();
                    System.out.println("Introdueix una nova paraula");
                    String gn = lector.next();
                    pa.set_p(gn);
                    if(pa.is_stop_word()) System.out.println(pa.get_p() + " es una stop word");
                    else System.out.println(pa.get_p() + " no es una stop word");
                    break;
               
           case 4: String st = lector.next();
                    Paraula su = new Paraula(st);
                    String ret = su.get_p();
                    System.out.println("La funcio get retorna correctament la paraula seguent: "+ret);
                    break;
       
           default:  System.out.println("Error: El numero ha de ser entre 1 i 4"); break;  
       }
        
    }
    
}
